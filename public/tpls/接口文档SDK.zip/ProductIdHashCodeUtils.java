package com.ytincl.sdk;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductIdHashCodeUtils {

	// 服务器地址
//	 private static final String BasicUrl = "http://111.40.165.100:8088";
//	 private static final String BasicUrl = "https://ggsypt.56saas.com.cn/gateway";
	 private static final String BasicUrl = "http://localhost:8088";

	// 证书：令牌
	private static final String credential = "042b487498fbad4934f0231b7dc4ece3";

	// 密钥
	private static final String secretkey = "81e2a99ed5459a5bf9a8da54b4f06d44";

	// 对字符串进行Base64编码/解码
	final static Base64.Encoder encoder = Base64.getEncoder();

	// 设置一个SALT增加复杂度
	private final static String SALT = "qrqhhufadfhsdqwer";

	// 批量获取唯一标识码个数
	private static int num = 1;

	// 通过唯一标识码和需要上链数据获取hash值
//	private static String jsonString = "[{\"depositMessage\":\"这是一条测试报文\",\"productId\":\"74001593744686777\",\"distinctId\":\"123\"},{\"depositMessage\":\"这是一条测试报文\",\"productId\":\"18901593744686777\",\"distinctId\":\"234\"}]";
	private static String jsonString = "[{\"depositMessage\":\"222\",\"productId\":\"524249345923756032\",\"distinctId\":\"123\"}]";
//	private static String jsonString = "[{\"depositMessage\":\"222\",\"productId\":\"524262833916227584\",\"distinctId\":\"123\"}]";

	// 通过唯一标识码查询链上数据
	private static String prodcutIdString = "74001593744686777";

	// 通过hashcode查询链上数据
	private static String hashCodeString = "dd66ee97f93c5d178656c4e41943cdefeff25546a717251c4c18cd4e6f1af9d1";

	public static void main(String[] args) throws IOException {
		// 批量获取唯一标识码
//		 System.out.println(getProductIdList(num));
		// 批量获取hash码
		 System.out.println(asynUploadInfoList(jsonString));
		// 通过唯一标识码查询
//		 System.out.println(getMsgById(prodcutIdString));
		// 通过hashcode查询链上数据
//		 System.out.println(getMsgByHash(hashCodeString));

		// 通过hashcode查询链上数据
//		 System.out.println(setProductIdForTraceCodeInfo("[74001593744686777,18901593744686777]"));
		// 通过hashcode查询链上数据
//		 System.out.println(uploadInfo("74001593744686777"));
		/// 通过hashcode查询链上数据
//		 System.out.println(getProductId("042b487498fbad4934f0231b7dc4ece3"));
		// 通过hashcode查询链上数
//		 System.out.println(getMsgByIdList("[74001593744686777,18901593744686777]"));

	}

	/*
	 * @param:证书:credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&需要获取的数量
	 * ：num=Mg==&密钥：signature=64de40cc5928bccf6dc9b3511fc65fd3&请求地址
	 * 
	 * @return:返回成功报文：{"code":"0000","message":"成功","msgBody":[
	 * "47171593653291948","77531593653291948"]}
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容,获取的唯一标识值
	 */
	public static String getProductIdList(int num) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("num", String.valueOf(num));

		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/upload/getProductIdList");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	public static String getRcCode(String url, String productId) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("productId", productId);
		parameterMap.put("url", url);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/getQRCode/QRCode");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&
	 * 上链数据和唯一标识码uploadBodys=
	 * VzNzblpHVndiM05wZEUxbGMzTmhaMlVuT2lkN0ltTnlaV0YwWlVsa0lqb3hNREFzSW1OeVpXRjBaVTVoYldVaU9pTG5ycUhua0libGtaZ2lMQ0pqY21WaGRHVlVhVzFsSWpveE5Ua3pOVGsxT1RVeE5UQXhMQ0pwYzBSbGJHVjBaV1FpT2lJd0lpd2liVzlrYVdacFpXUkpaQ0k2TVRBd0xDSnRiMlJwWm1sbFpFNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSnRiMlJwWm1sbFpGUnBiV1VpT2pFMU9UTTFPVFU1TlRFMU1ERXNJbTl3UTI5a1pTSTZJakl3TXlJc0ltOXdSR1Z6WXlJNkl1T0FrT1dNbCtTNnJPUzRyZVcvZytPQWtlVzNzdWFVdHVXdmhDSXNJbTl3VG1GdFpTSTZJdVczc3VhVXR1V3ZoQ0lzSW05d1QzSm5RMmwwZVNJNkl1V01sK1M2ckNJc0ltOXdUM0puUTI5a1pTSTZJakV3TURBd01EQXhJaXdpYjNCUGNtZE9ZVzFsSWpvaTVMaXQ1WnU5NllLdTVwUy81NG1wNXJXQjVZeVg1THFzNWErRTZZQ1M1Ym16NVkrd0lpd2liM0JQY21kUWNtOTJUbUZ0WlNJNkl1V01sK1M2ckNJc0ltOXdWR2x0WlNJNk1UVTVNelU1TlRrMU1UVXdNQ3dpYjNCbGNtRjBiM0pPWVcxbElqb2k1cDJPNW9DZElpd2liM0JsY21GMGIzSk9ieUk2SWpFd01EQXhNak0wSWl3aWRISmhZMlZPYnlJNklqSXlJbjBuTENkd2NtOWtkV04wU1dRbk9pYzBOekUzTVRVNU16WTFNekk1TVRrME9DZDlMSHNuWkdWd2IzTnBkRTFsYzNOaFoyVW5PaWQ3SW1OeVpXRjBaVWxrSWpveE1EQXNJbU55WldGMFpVNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSmpjbVZoZEdWVWFXMWxJam94TlRrek5UazFPVFV4TlRBeExDSnBjMFJsYkdWMFpXUWlPaUl3SWl3aWJXOWthV1pwWldSSlpDSTZNVEF3TENKdGIyUnBabWxsWkU1aGJXVWlPaUxucnFIbmtJYmxrWmdpTENKdGIyUnBabWxsWkZScGJXVWlPakUxT1RNMU9UVTVOVEUxTURFc0ltOXdRMjlrWlNJNklqSXdNeUlzSW05d1JHVnpZeUk2SXVPQWtPV01sK1M2ck9TNHJlVy9nK09Ba2VXM3N1YVV0dVd2aENJc0ltOXdUbUZ0WlNJNkl1VzNzdWFVdHVXdmhDSXNJbTl3VDNKblEybDBlU0k2SXVXTWwrUzZyQ0lzSW05d1QzSm5RMjlrWlNJNklqRXdNREF3TURBeElpd2liM0JQY21kT1lXMWxJam9pNUxpdDVadTk2WUt1NXBTLzU0bXA1cldCNVl5WDVMcXM1YStFNllDUzVibXo1WSt3SWl3aWIzQlBjbWRRY205MlRtRnRaU0k2SXVXTWwrUzZyQ0lzSW05d1ZHbHRaU0k2TVRVNU16VTVOVGsxTVRVd01Dd2liM0JsY21GMGIzSk9ZVzFsSWpvaTVwMk81b0NkSWl3aWIzQmxjbUYwYjNKT2J5STZJakV3TURBeE1qTTBJaXdpZEhKaFkyVk9ieUk2SWpJeUluMG5MQ2R3Y205a2RXTjBTV1FuT2ljME56RTNNVFU1TXpZMU16STVNVGswT0NkOVhRPT0
	 * =&密钥：signature=487c0b9b5f447ddf4efcd5589ca38cc2&请求地址
	 * 
	 * @return:返回成功报文：{"code":"0000","message":"成功","msgBody":[{"code":"0",
	 * "message":"成功","txhash":
	 * "91e33ae3c3c00e07b417e442abd54666c7d8fd4a34b59dd21395d93a853ea8bc",
	 * "productId":"47171593653291948"},{"code":"0","message":"成功","txhash":
	 * "280943086b0dbbbad2b3d44a8e2b9c181152e8dea01e0d5b9d3a95c63e6ddd6d",
	 * "productId":"47171593653291948"}]}
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容，批量上链获取hash值返回数据。 code：成功失败标识，成功：0；失败：1
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 txhash：生成上链的hash值 productId：唯一标识码
	 */
	public static String asynUploadInfoList(String jsonString) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("uploadBodys", jsonString);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/upload/asynUploadInfoList");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书:credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&
	 * 唯一标识码productId=NDcxNzE1OTM2NTMyOTE5NDg=&密钥signature=
	 * 47a8122196d0a5796e4a5e70f3806b87请求地址
	 * 
	 * @return:返回报文：{"code":"0000","message":"成功","msgBody":[{"message":"成功",
	 * "msgBody":
	 * "{\"createId\":100,\"createName\":\"管理员\",\"createTime\":1593595951501,\"isDeleted\":\"0\",\"modifiedId\":100,\"modifiedName\":\"管理员\",\"modifiedTime\":1593595951501,\"opCode\":\"203\",\"opDesc\":\"【北京中心】已收寄\",\"opName\":\"已收寄\",\"opOrgCity\":\"北京\",\"opOrgCode\":\"10000001\",\"opOrgName\":\"中国邮政物流北京寄递平台\",\"opOrgProvName\":\"北京\",\"opTime\":1593595951500,\"operatorName\":\"李思\",\"operatorNo\":\"10001234\",\"traceNo\":\"22\"}"
	 * ,"blockNum":"11684215","blockCreateTime":"2020-07-02 09:56:23" ,"blockHash":
	 * "d45d5f7e6f3fe3b97e0641b576eb6f0f7956bbe36425f2eb086edd52d736f193", "txhash":
	 * "91e33ae3c3c00e07b417e442abd54666c7d8fd4a34b59dd21395d93a853ea8bc"},{
	 * "message":"成功","msgBody":
	 * "{\"createId\":100,\"createName\":\"管理员\",\"createTime\":1593595951501,\"isDeleted\":\"0\",\"modifiedId\":100,\"modifiedName\":\"管理员\",\"modifiedTime\":1593595951501,\"opCode\":\"203\",\"opDesc\":\"【北京中心】已收寄\",\"opName\":\"已收寄\",\"opOrgCity\":\"北京\",\"opOrgCode\":\"10000001\",\"opOrgName\":\"中国邮政物流北京寄递平台\",\"opOrgProvName\":\"北京\",\"opTime\":1593595951500,\"operatorName\":\"李思\",\"operatorNo\":\"10001234\",\"traceNo\":\"22\"}"
	 * ,"blockNum":"11684216","blockCreateTime":"2020-07-02 09:56:23" ,"blockHash":
	 * "6013d7355f5b4228b2c5aae557b78e51d0b6cfe2643b7bf8f31dc6e59abd2ffc", "txhash":
	 * "280943086b0dbbbad2b3d44a8e2b9c181152e8dea01e0d5b9d3a95c63e6ddd6d"}]}
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容,通过唯一标识码获取的消息体 message：成功失败消息，成功时值为成功，失败时值为失败原因 msgBody：返回内容{
	 * blockNum：区块高度 msgBody：链上的数据 blockCreateTime：区块创建时间 blockHash：区块hash值
	 * txhash:上链hash值 }
	 */
	public static String getMsgById(String productId) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("productId", productId);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/search/getMsgById");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书:credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&hash值：
	 * txHash=
	 * OTFlMzNhZTNjM2MwMGUwN2I0MTdlNDQyYWJkNTQ2NjZjN2Q4ZmQ0YTM0YjU5ZGQyMTM5NWQ5M2E4NTNlYThiYw
	 * ==&密钥：signature=664fe5dac352cc62b8c291aa2497829e&请求地址
	 * 
	 * @return:返回报文：
	 * {"code":"0000","message":"成功","msgBody":{"code":"0","message":"成功",
	 * "msgBody":
	 * "{\"createId\":100,\"createName\":\"管理员\",\"createTime\":1593595951501,\"isDeleted\":\"0\",\"modifiedId\":100,\"modifiedName\":\"管理员\",\"modifiedTime\":1593595951501,\"opCode\":\"203\",\"opDesc\":\"【北京中心】已收寄\",\"opName\":\"已收寄\",\"opOrgCity\":\"北京\",\"opOrgCode\":\"10000001\",\"opOrgName\":\"中国邮政物流北京寄递平台\",\"opOrgProvName\":\"北京\",\"opTime\":1593595951500,\"operatorName\":\"李思\",\"operatorNo\":\"10001234\",\"traceNo\":\"22\"}"
	 * ,"blockNum":"11684215","blockCreateTime":"2020-07-02 09:56:23" ,"blockHash":
	 * "d45d5f7e6f3fe3b97e0641b576eb6f0f7956bbe36425f2eb086edd52d736f193", "txhash":
	 * "91e33ae3c3c00e07b417e442abd54666c7d8fd4a34b59dd21395d93a853ea8bc"}}
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容,通过唯一标识码获取的消息体 code：成功失败标识，成功：0；失败：1
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 msgBody：返回内容{ blockNum：区块高度 msgBody：链上的数据
	 * blockCreateTime：区块创建时间 blockHash：区块hash值 txhash:上链hash值 }
	 */
	public static String getMsgByHash(String hashCode) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("txHash", hashCode);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/search/getMsgByHash");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书:credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&hash值：
	 * txHash=
	 * OTFlMzNhZTNjM2MwMGUwN2I0MTdlNDQyYWJkNTQ2NjZjN2Q4ZmQ0YTM0YjU5ZGQyMTM5NWQ5M2E4NTNlYThiYw
	 * ==&密钥：signature=664fe5dac352cc62b8c291aa2497829e&请求地址
	 * 
	 * @return:返回报文：{"code":"0000","message":"成功"} code：成功失败标识，成功：0000；失败：9999
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 msgBody：消息内容,通过唯一标识码获取的消息体
	 * code：成功失败标识，成功：0；失败：1 message：成功失败消息，成功时值为成功，失败时值为失败原因 }
	 */
	public static String setProductIdForTraceCodeInfo(String jsonString) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("uploadBodys", jsonString);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey,
					BasicUrl + "/uxp-api/upload/setProductIdForTraceCodeInfo");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&
	 * signature=48986b6b7591d726c7409f3e8115cc62上链数据和唯一标识码uploadBodys=
	 * VzNzblpHVndiM05wZEUxbGMzTmhaMlVuT2lkN0ltTnlaV0YwWlVsa0lqb3hNREFzSW1OeVpXRjBaVTVoYldVaU9pTG5ycUhua0libGtaZ2lMQ0pqY21WaGRHVlVhVzFsSWpveE5Ua3pOVGsxT1RVeE5UQXhMQ0pwYzBSbGJHVjBaV1FpT2lJd0lpd2liVzlrYVdacFpXUkpaQ0k2TVRBd0xDSnRiMlJwWm1sbFpFNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSnRiMlJwWm1sbFpGUnBiV1VpT2pFMU9UTTFPVFU1TlRFMU1ERXNJbTl3UTI5a1pTSTZJakl3TXlJc0ltOXdSR1Z6WXlJNkl1T0FrT1dNbCtTNnJPUzRyZVcvZytPQWtlVzNzdWFVdHVXdmhDSXNJbTl3VG1GdFpTSTZJdVczc3VhVXR1V3ZoQ0lzSW05d1QzSm5RMmwwZVNJNkl1V01sK1M2ckNJc0ltOXdUM0puUTI5a1pTSTZJakV3TURBd01EQXhJaXdpYjNCUGNtZE9ZVzFsSWpvaTVMaXQ1WnU5NllLdTVwUy81NG1wNXJXQjVZeVg1THFzNWErRTZZQ1M1Ym16NVkrd0lpd2liM0JQY21kUWNtOTJUbUZ0WlNJNkl1V01sK1M2ckNJc0ltOXdWR2x0WlNJNk1UVTVNelU1TlRrMU1UVXdNQ3dpYjNCbGNtRjBiM0pPWVcxbElqb2k1cDJPNW9DZElpd2liM0JsY21GMGIzSk9ieUk2SWpFd01EQXhNak0wSWl3aWRISmhZMlZPYnlJNklqSXlJbjBuTENkd2NtOWtkV04wU1dRbk9pYzBOekUzTVRVNU16WTFNekk1TVRrME9DZDlMSHNuWkdWd2IzTnBkRTFsYzNOaFoyVW5PaWQ3SW1OeVpXRjBaVWxrSWpveE1EQXNJbU55WldGMFpVNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSmpjbVZoZEdWVWFXMWxJam94TlRrek5UazFPVFV4TlRBeExDSnBjMFJsYkdWMFpXUWlPaUl3SWl3aWJXOWthV1pwWldSSlpDSTZNVEF3TENKdGIyUnBabWxsWkU1aGJXVWlPaUxucnFIbmtJYmxrWmdpTENKdGIyUnBabWxsWkZScGJXVWlPakUxT1RNMU9UVTVOVEUxTURFc0ltOXdRMjlrWlNJNklqSXdNeUlzSW05d1JHVnpZeUk2SXVPQWtPV01sK1M2ck9TNHJlVy9nK09Ba2VXM3N1YVV0dVd2aENJc0ltOXdUbUZ0WlNJNkl1VzNzdWFVdHVXdmhDSXNJbTl3VDNKblEybDBlU0k2SXVXTWwrUzZyQ0lzSW05d1QzSm5RMjlrWlNJNklqRXdNREF3TURBeElpd2liM0JQY21kT1lXMWxJam9pNUxpdDVadTk2WUt1NXBTLzU0bXA1cldCNVl5WDVMcXM1YStFNllDUzVibXo1WSt3SWl3aWIzQlBjbWRRY205MlRtRnRaU0k2SXVXTWwrUzZyQ0lzSW05d1ZHbHRaU0k2TVRVNU16VTVOVGsxTVRVd01Dd2liM0JsY21GMGIzSk9ZVzFsSWpvaTVwMk81b0NkSWl3aWIzQmxjbUYwYjNKT2J5STZJakV3TURBeE1qTTBJaXdpZEhKaFkyVk9ieUk2SWpJeUluMG5MQ2R3Y205a2RXTjBTV1FuT2ljME56RTNNVFU1TXpZMU16STVNVGswT0NkOVhRPT0
	 * =&密钥：signature=487c0b9b5f447ddf4efcd5589ca38cc2&请求地址
	 * 
	 * @return:返回成功报文：{"code":"0000","message":"成功","msgBody":
	 * "86371593746419553"}{"code":"0000","message":"成功","msgBody":
	 * "f66b6ab33d28272fb6428eff6f81938a96aeed3c1050ae8fb3cdfcb1d45e310f"}
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容，批量上链获取hash值返回数据。 code：成功失败标识，成功：0；失败：1
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 txhash：生成上链的hash值 productId：唯一标识码
	 * 
	 */
	public static String uploadInfo(String productId) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		parameterMap.put("productId", productId);
		parameterMap.put("depositMessage", productId);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/upload/uploadInfo");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&
	 * signature=48986b6b7591d726c7409f3e8115cc62上链数据和唯一标识码uploadBodys=
	 * VzNzblpHVndiM05wZEUxbGMzTmhaMlVuT2lkN0ltTnlaV0YwWlVsa0lqb3hNREFzSW1OeVpXRjBaVTVoYldVaU9pTG5ycUhua0libGtaZ2lMQ0pqY21WaGRHVlVhVzFsSWpveE5Ua3pOVGsxT1RVeE5UQXhMQ0pwYzBSbGJHVjBaV1FpT2lJd0lpd2liVzlrYVdacFpXUkpaQ0k2TVRBd0xDSnRiMlJwWm1sbFpFNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSnRiMlJwWm1sbFpGUnBiV1VpT2pFMU9UTTFPVFU1TlRFMU1ERXNJbTl3UTI5a1pTSTZJakl3TXlJc0ltOXdSR1Z6WXlJNkl1T0FrT1dNbCtTNnJPUzRyZVcvZytPQWtlVzNzdWFVdHVXdmhDSXNJbTl3VG1GdFpTSTZJdVczc3VhVXR1V3ZoQ0lzSW05d1QzSm5RMmwwZVNJNkl1V01sK1M2ckNJc0ltOXdUM0puUTI5a1pTSTZJakV3TURBd01EQXhJaXdpYjNCUGNtZE9ZVzFsSWpvaTVMaXQ1WnU5NllLdTVwUy81NG1wNXJXQjVZeVg1THFzNWErRTZZQ1M1Ym16NVkrd0lpd2liM0JQY21kUWNtOTJUbUZ0WlNJNkl1V01sK1M2ckNJc0ltOXdWR2x0WlNJNk1UVTVNelU1TlRrMU1UVXdNQ3dpYjNCbGNtRjBiM0pPWVcxbElqb2k1cDJPNW9DZElpd2liM0JsY21GMGIzSk9ieUk2SWpFd01EQXhNak0wSWl3aWRISmhZMlZPYnlJNklqSXlJbjBuTENkd2NtOWtkV04wU1dRbk9pYzBOekUzTVRVNU16WTFNekk1TVRrME9DZDlMSHNuWkdWd2IzTnBkRTFsYzNOaFoyVW5PaWQ3SW1OeVpXRjBaVWxrSWpveE1EQXNJbU55WldGMFpVNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSmpjbVZoZEdWVWFXMWxJam94TlRrek5UazFPVFV4TlRBeExDSnBjMFJsYkdWMFpXUWlPaUl3SWl3aWJXOWthV1pwWldSSlpDSTZNVEF3TENKdGIyUnBabWxsWkU1aGJXVWlPaUxucnFIbmtJYmxrWmdpTENKdGIyUnBabWxsWkZScGJXVWlPakUxT1RNMU9UVTVOVEUxTURFc0ltOXdRMjlrWlNJNklqSXdNeUlzSW05d1JHVnpZeUk2SXVPQWtPV01sK1M2ck9TNHJlVy9nK09Ba2VXM3N1YVV0dVd2aENJc0ltOXdUbUZ0WlNJNkl1VzNzdWFVdHVXdmhDSXNJbTl3VDNKblEybDBlU0k2SXVXTWwrUzZyQ0lzSW05d1QzSm5RMjlrWlNJNklqRXdNREF3TURBeElpd2liM0JQY21kT1lXMWxJam9pNUxpdDVadTk2WUt1NXBTLzU0bXA1cldCNVl5WDVMcXM1YStFNllDUzVibXo1WSt3SWl3aWIzQlBjbWRRY205MlRtRnRaU0k2SXVXTWwrUzZyQ0lzSW05d1ZHbHRaU0k2TVRVNU16VTVOVGsxTVRVd01Dd2liM0JsY21GMGIzSk9ZVzFsSWpvaTVwMk81b0NkSWl3aWIzQmxjbUYwYjNKT2J5STZJakV3TURBeE1qTTBJaXdpZEhKaFkyVk9ieUk2SWpJeUluMG5MQ2R3Y205a2RXTjBTV1FuT2ljME56RTNNVFU1TXpZMU16STVNVGswT0NkOVhRPT0
	 * =&密钥：signature=487c0b9b5f447ddf4efcd5589ca38cc2&请求地址
	 * 
	 * @return:返回成功报文：{"code":"0000","message":"成功","msgBody": "86371593746419553"}
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容，批量上链获取hash值返回数据。 code：成功失败标识，成功：0；失败：1
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 txhash：生成上链的hash值 productId：唯一标识码 jsonString
	 * 是上链信息
	 */
	public static String getProductId(String credential) {
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("credential", credential);
		// parameterMap.put("ProductId",credential);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/upload/getProductId");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/*
	 * @param:证书credential=MDQyYjQ4NzQ5OGZiYWQ0OTM0ZjAyMzFiN2RjNGVjZTM=&
	 * 上链数据和唯一标识码uploadBodys=
	 * VzNzblpHVndiM05wZEUxbGMzTmhaMlVuT2lkN0ltTnlaV0YwWlVsa0lqb3hNREFzSW1OeVpXRjBaVTVoYldVaU9pTG5ycUhua0libGtaZ2lMQ0pqY21WaGRHVlVhVzFsSWpveE5Ua3pOVGsxT1RVeE5UQXhMQ0pwYzBSbGJHVjBaV1FpT2lJd0lpd2liVzlrYVdacFpXUkpaQ0k2TVRBd0xDSnRiMlJwWm1sbFpFNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSnRiMlJwWm1sbFpGUnBiV1VpT2pFMU9UTTFPVFU1TlRFMU1ERXNJbTl3UTI5a1pTSTZJakl3TXlJc0ltOXdSR1Z6WXlJNkl1T0FrT1dNbCtTNnJPUzRyZVcvZytPQWtlVzNzdWFVdHVXdmhDSXNJbTl3VG1GdFpTSTZJdVczc3VhVXR1V3ZoQ0lzSW05d1QzSm5RMmwwZVNJNkl1V01sK1M2ckNJc0ltOXdUM0puUTI5a1pTSTZJakV3TURBd01EQXhJaXdpYjNCUGNtZE9ZVzFsSWpvaTVMaXQ1WnU5NllLdTVwUy81NG1wNXJXQjVZeVg1THFzNWErRTZZQ1M1Ym16NVkrd0lpd2liM0JQY21kUWNtOTJUbUZ0WlNJNkl1V01sK1M2ckNJc0ltOXdWR2x0WlNJNk1UVTVNelU1TlRrMU1UVXdNQ3dpYjNCbGNtRjBiM0pPWVcxbElqb2k1cDJPNW9DZElpd2liM0JsY21GMGIzSk9ieUk2SWpFd01EQXhNak0wSWl3aWRISmhZMlZPYnlJNklqSXlJbjBuTENkd2NtOWtkV04wU1dRbk9pYzBOekUzTVRVNU16WTFNekk1TVRrME9DZDlMSHNuWkdWd2IzTnBkRTFsYzNOaFoyVW5PaWQ3SW1OeVpXRjBaVWxrSWpveE1EQXNJbU55WldGMFpVNWhiV1VpT2lMbnJxSG5rSWJsa1pnaUxDSmpjbVZoZEdWVWFXMWxJam94TlRrek5UazFPVFV4TlRBeExDSnBjMFJsYkdWMFpXUWlPaUl3SWl3aWJXOWthV1pwWldSSlpDSTZNVEF3TENKdGIyUnBabWxsWkU1aGJXVWlPaUxucnFIbmtJYmxrWmdpTENKdGIyUnBabWxsWkZScGJXVWlPakUxT1RNMU9UVTVOVEUxTURFc0ltOXdRMjlrWlNJNklqSXdNeUlzSW05d1JHVnpZeUk2SXVPQWtPV01sK1M2ck9TNHJlVy9nK09Ba2VXM3N1YVV0dVd2aENJc0ltOXdUbUZ0WlNJNkl1VzNzdWFVdHVXdmhDSXNJbTl3VDNKblEybDBlU0k2SXVXTWwrUzZyQ0lzSW05d1QzSm5RMjlrWlNJNklqRXdNREF3TURBeElpd2liM0JQY21kT1lXMWxJam9pNUxpdDVadTk2WUt1NXBTLzU0bXA1cldCNVl5WDVMcXM1YStFNllDUzVibXo1WSt3SWl3aWIzQlBjbWRRY205MlRtRnRaU0k2SXVXTWwrUzZyQ0lzSW05d1ZHbHRaU0k2TVRVNU16VTVOVGsxTVRVd01Dd2liM0JsY21GMGIzSk9ZVzFsSWpvaTVwMk81b0NkSWl3aWIzQmxjbUYwYjNKT2J5STZJakV3TURBeE1qTTBJaXdpZEhKaFkyVk9ieUk2SWpJeUluMG5MQ2R3Y205a2RXTjBTV1FuT2ljME56RTNNVFU1TXpZMU16STVNVGswT0NkOVhRPT0
	 * =&密钥：signature=487c0b9b5f447ddf4efcd5589ca38cc2&请求地址
	 * 
	 * @return:返回成功报文：{"code":"0000","message":"成功","msgBody":[{"productId":
	 * "74001593744686777","depositList":[{"message":"成功","msgBody":
	 * "{\"createId\":100,\"createName\":\"管理员\",\"createTime\":1593595951501,\"isDeleted\":\"0\",\"modifiedId\":100,\"modifiedName\":\"管理员\",\"modifiedTime\":1593595951501,\"opCode\":\"203\",\"opDesc\":\"【北京中心】已收寄\",\"opName\":\"已收寄\",\"opOrgCity\":\"北京\",\"opOrgCode\":\"10000001\",\"opOrgName\":\"中国邮政物流北京寄递平台\",\"opOrgProvName\":\"北京\",\"opTime\":1593595951500,\"operatorName\":\"李思\",\"operatorNo\":\"10001234\",\"traceNo\":\"22\"}"
	 * ,"blockNum":"2323187","blockCreateTime":"2020-07-03 10:53:48","blockHash"
	 * :"ee712c8365885410c374ea44a4ff6cb6257a388fb566030774390e64cea4ec0c",
	 * "txhash":
	 * "dd66ee97f93c5d178656c4e41943cdefeff25546a717251c4c18cd4e6f1af9d1"}]},{
	 * "productId":"18901593744686777","depositList":[{"message":"成功","msgBody":
	 * "{\"createId\":100,\"createName\":\"管理员\",\"createTime\":1593595951501,\"isDeleted\":\"0\",\"modifiedId\":100,\"modifiedName\":\"管理员\",\"modifiedTime\":1593595951501,\"opCode\":\"203\",\"opDesc\":\"【北京中心】已收寄\",\"opName\":\"已收寄\",\"opOrgCity\":\"北京\",\"opOrgCode\":\"10000001\",\"opOrgName\":\"中国邮政物流北京寄递平台\",\"opOrgProvName\":\"北京\",\"opTime\":1593595951500,\"operatorName\":\"李思\",\"operatorNo\":\"10001234\",\"traceNo\":\"22\"}"
	 * ,"blockNum":"2323188","blockCreateTime":"2020-07-03 10:53:49","blockHash"
	 * :"1a230d9bf9ed874607432efdefc78a62b99bf187d95bdfe87c0c5b66884b46a7",
	 * "txhash":
	 * "edb4cb1cf97625ee6aa9bedf004ff6f3edbaf9e61e9fdf2c019e3af32be97d51"}]}]}
	 * 
	 * 
	 * code：成功失败标识，成功：0000；失败：9999 message：成功失败消息，成功时值为成功，失败时值为失败原因
	 * msgBody：消息内容，批量上链获取hash值返回数据。 code：成功失败标识，成功：0；失败：1
	 * message：成功失败消息，成功时值为成功，失败时值为失败原因 txhash：生成上链的hash值 productId：唯一标识码 jsonString
	 * 是上链信息
	 */
	public static String getMsgByIdList(String jsonString) {
		Map<String, String> parameterMap = new HashMap<>();
		// String encodeToString =
		// encoder.encodeToString(jsonString.getBytes());
		parameterMap.put("credential", credential);
		parameterMap.put("productIds", jsonString);
		String sendPost = "";
		try {
			sendPost = sendPost(parameterMap, credential, secretkey, BasicUrl + "/uxp-api/search/getMsgByIdList");
		} catch (IOException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		return sendPost;
	}

	/**
	 * 使用HttpURLConnection实现POST请求
	 *
	 * 1.实例化一个java.net.URL对象；
	 * 2.通过URL对象的openConnection()方法得到一个java.net.URLConnection;
	 * 3.通过URLConnection对象的getOutputStream()方法获得输出流； 4.向输出流中写数据； 5.关闭资源；
	 */
	static String sendPost(Map<String, String> parameterMap, String credential, String secretkey, String URL)
			throws IOException {
		URL url = new URL(URL);
		HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
		httpURLConnection.setDoInput(true);
		httpURLConnection.setDoOutput(true); // 设置该连接是可以输出的
		httpURLConnection.setRequestMethod("POST"); // 设置请求方式
		httpURLConnection.setRequestProperty("charset", "utf-8");
		// httpURLConnection.setRequestProperty("Content-Type",
		// "application/json");
		PrintWriter pw = new PrintWriter(new BufferedOutputStream(httpURLConnection.getOutputStream()));
		pw.write(createSign(parameterMap, credential, secretkey));// 向连接中写数据（相当于发送数据给服务器）
		pw.flush();
		pw.close();
		System.out.println("参数: " + createSign(parameterMap, credential, secretkey));

		BufferedReader br = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "utf-8"));
		String line = null;
		StringBuilder sb = new StringBuilder();
		while ((line = br.readLine()) != null) {
			// 读取数据
			sb.append(line + "\n");
		}
		br.close();
		return sb.toString();
	}

	/**
	 * 该方法用于根据传来的map和credential，secretkey生成参数串
	 */
	private static String createSign(Map<String, String> map, String credential, String secretkey) {
		String result = "";
		String middleResult = "";
		String signature = "";
		String finalResult = "";
		try {
			List<Map.Entry<String, String>> infoIds = new ArrayList<Map.Entry<String, String>>(map.entrySet());
			// 对所有传入参数按照字段名的 ASCII 码从小到大排序（字典序）
			Collections.sort(infoIds, new Comparator<Map.Entry<String, String>>() {
				public int compare(Map.Entry<String, String> o1, Map.Entry<String, String> o2) {
					return ((o1.getKey()).toString().compareTo(o2.getKey()));
				}
			});
			// 构造签名键值对的格式
			StringBuilder sb = new StringBuilder();
			StringBuilder sb1 = new StringBuilder();
			// Base64 base64 = new Base64();
			for (Map.Entry<String, String> item : infoIds) {
				if (item.getKey() != null && item.getKey() != "") {
					String key = item.getKey();
					String val = item.getValue();
					if (!(val == "" || val == null)) {
						sb.append(key + "=" + val + "&");
						sb1.append(key + "=" + encoder.encodeToString(val.getBytes("UTF-8")) + "&");
					}
				}
			}
			// 去掉字符串中最后一个字符
			middleResult = sb.toString();
			if (middleResult != null && middleResult.length() != 0) {
				result = middleResult.substring(0, middleResult.length() - 1);
			}
			// 进行MD5哈希
			signature = getMD5WithSalt(result + credential + secretkey);
			sb1.append("signature" + "=" + signature);
			finalResult = sb1.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return finalResult;
	}

	/**
	 * MD5加密操作
	 * 
	 * @param string
	 */
	public static String getMD5(String string) {
		StringBuilder sb = new StringBuilder();
		try {
			// 获取数据摘要器
			// 参数：加密的方式
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			// 摘要数据
			// 参数：将要加密的明文转成byte数组
			byte[] digest = messageDigest.digest(string.getBytes());
			// 加密操作
			for (int i = 0; i < digest.length; i++) {
				// MD5加密的核心原理：将一个byte数组通过与int类型进&运算得到一个int类型的正整数
				int result = digest[i] & 0xff;
				// 可能得到的int数据会造成MD%加密的密文比较长，所以进行一个16进制的转换
				String hexString = Integer.toHexString(result);
				if (hexString.length() < 2) {
					sb.append("0");
				}
				sb.append(hexString);
			}
			return sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return string;
	}

	/**
	 * 获取加盐的MD5字符串
	 */
	public static String getMD5WithSalt(String content) {
		return getMD5(getMD5(content) + SALT);
	}
}
